/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 *
 * @author IIslamsoft
 */
class AdminMainFrame extends JFrame {
    public AdminMainFrame() {
        setTitle("Admin Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Employee Management Tab
        tabbedPane.addTab("Employee Management", new EmployeeManagementPanel());
        
        // Customer Reviews Tab
        tabbedPane.addTab("Customer Reviews", new CustomerReviewsPanel());
        
        add(tabbedPane);
    }
}
