/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author IIslamsoft
 */

class CustomerMainFrame extends JFrame {
    private int customerId;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JPanel topBar;
    private JLabel cartCountLabel;
    private ArrayList<CartItem> cart = new ArrayList<>();
    private JPanel cartItemsPanel = new JPanel();
    private JLabel totalLabel = new JLabel("Total: 0 SAR");

    public CustomerMainFrame(int customerId) {
        this.customerId = customerId;
        setTitle("Precious Online Clothing Store");
        setSize(1100, 810);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        topBar = createTopBar();
        add(topBar, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);

        mainPanel.add(createDashboardPanel(), "dashboard");
        mainPanel.add(createCartPanel(), "cart");
        mainPanel.add(createPaymentPanel(), "payment");
mainPanel.add(createCreditCardFormPanel(), "creditForm");
        cardLayout.show(mainPanel, "dashboard");
    }

   private JPanel createTopBar() {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    panel.setBackground(Color.LIGHT_GRAY);

    // Load cart image icon
    ImageIcon cartIcon = new ImageIcon("cart.png"); // adjust path as needed
    Image img = cartIcon.getImage().getScaledInstance(24, 24, Image.SCALE_SMOOTH); // resize if needed
    cartIcon = new ImageIcon(img);

    JButton cartButton = new JButton(cartIcon);
    cartButton.setPreferredSize(new Dimension(40, 40)); // optional
    cartButton.setFocusPainted(false);
    cartButton.setContentAreaFilled(false);
    cartButton.setBorderPainted(false);

    cartButton.addActionListener(e -> {
        updateCartDisplay();
        cardLayout.show(mainPanel, "cart");
    });

    cartCountLabel = new JLabel("0");
    cartCountLabel.setFont(new Font("Arial", Font.BOLD, 16));
    cartCountLabel.setForeground(Color.RED);

    panel.add(cartButton);
    panel.add(cartCountLabel);

    return panel;
}


    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        panel.setBackground(Color.WHITE);

        JPanel dressesPanel = new JPanel(new BorderLayout(10, 10));
        JLabel dressesImage = new JLabel(new ImageIcon("dresse.jpg"));
        dressesImage.setHorizontalAlignment(SwingConstants.CENTER);

        JButton dressesButton = new JButton("Women's Dresses");
        dressesButton.setFont(new Font("Arial", Font.BOLD, 18));
        dressesButton.addActionListener(e -> showProducts("Dress"));

        dressesPanel.add(dressesImage, BorderLayout.CENTER);
        dressesPanel.add(dressesButton, BorderLayout.SOUTH);

        JPanel suitsPanel = new JPanel(new BorderLayout(10, 10));
        JLabel suitsImage = new JLabel(new ImageIcon("F.jpg"));
        suitsImage.setHorizontalAlignment(SwingConstants.CENTER);

        JButton suitsButton = new JButton("Men's Suits");
        suitsButton.setFont(new Font("Arial", Font.BOLD, 18));
        suitsButton.addActionListener(e -> showProducts("Suit"));

        suitsPanel.add(suitsImage, BorderLayout.CENTER);
        suitsPanel.add(suitsButton, BorderLayout.SOUTH);

        panel.add(dressesPanel);
        panel.add(suitsPanel);

        return panel;
    }

    private void showProducts(String category) {
        JPanel productsPanel = new JPanel(new BorderLayout());
        JPanel gridPanel = new JPanel(new GridLayout(0, 3, 20, 20));
        gridPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM products WHERE category = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, category);
                ResultSet rs = stmt.executeQuery();
                
                while (rs.next()) {
                    int productId = rs.getInt("product_id");
                    String name = rs.getString("name");
                    String imagePath = rs.getString("image_path");

                    JPanel productPanel = createProductPanel(productId, name, imagePath);
                    gridPanel.add(productPanel);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading products: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }

        JButton backButton = new JButton("Back to Dashboard");
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "dashboard"));

        productsPanel.add(gridPanel, BorderLayout.CENTER);
        productsPanel.add(backButton, BorderLayout.SOUTH);

        mainPanel.add(productsPanel, "products");
        cardLayout.show(mainPanel, "products");
    }

    private JPanel createProductPanel(int productId, String name, String imagePath) {
        JPanel panel = new JPanel(new BorderLayout());
        
        JLabel imageLabel = new JLabel(new ImageIcon(imagePath));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel nameLabel = new JLabel(name, SwingConstants.CENTER);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        JButton detailsButton = new JButton("View Details");
        detailsButton.addActionListener(e -> showProductDetails(productId));
        
        JButton addToCartButton = new JButton("Add to Cart");
        addToCartButton.addActionListener(e -> {
            addToCart(productId, name, 150); // Base price would come from database
            JOptionPane.showMessageDialog(this, name + " added to cart!");
        });
        
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
        buttonPanel.add(detailsButton);
        buttonPanel.add(addToCartButton);
        
        panel.add(imageLabel, BorderLayout.CENTER);
        panel.add(nameLabel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private void showProductDetails(int productId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM products WHERE product_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, productId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    String name = rs.getString("name");
                    String description = rs.getString("description");
                    String imagePath = rs.getString("image_path");
                    
                    JPanel detailsPanel = createProductDetailsPanel(productId, name, description, imagePath);
                    mainPanel.add(detailsPanel, "productDetails");
                    cardLayout.show(mainPanel, "productDetails");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading product details: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createProductDetailsPanel(int productId, String name, String description, String imagePath) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
    
        JLabel imageLabel = new JLabel(new ImageIcon(imagePath));
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        JLabel nameLabel = new JLabel(name);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 24));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        JLabel sizeLabel = new JLabel("Sizes: S, M, L, XL");
        sizeLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        sizeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        JLabel descriptionLabel = new JLabel("Description: " + description);
        descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        descriptionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        JTextField reviewField = new JTextField();
        reviewField.setMaximumSize(new Dimension(400, 30));
    
        JButton submitReview = new JButton("Submit Review");
        submitReview.setAlignmentX(Component.CENTER_ALIGNMENT);
        submitReview.addActionListener(e -> submitReview(productId, reviewField.getText()));
    
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 18));
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "products"));
    
        panel.add(imageLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(nameLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(sizeLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(descriptionLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        JPanel reviewLabelPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        reviewLabelPanel.setBackground(Color.WHITE);
        JLabel reviewLabel = new JLabel("Leave a Review:");
        reviewLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        reviewLabelPanel.add(reviewLabel);

        panel.add(reviewLabelPanel);
        panel.add(reviewField);
        panel.add(submitReview);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(backButton);
    
        return panel;
    }

    private void submitReview(int productId, String reviewText) {
        if (reviewText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a review", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO reviews (customer_id, product_id, review_text) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, customerId);
                stmt.setInt(2, productId);
                stmt.setString(3, reviewText);
                stmt.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Thank you for your review!", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error submitting review: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createCartPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(250, 250, 255));

        JLabel title = new JLabel("\uD83D\uDED2 Your Shopping Cart", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setForeground(new Color(60, 60, 120));

        cartItemsPanel.setLayout(new BoxLayout(cartItemsPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(cartItemsPanel);

        JButton checkout = new JButton("Proceed to Payment");
        JButton back = new JButton("Back to Dashboard");

        checkout.addActionListener(e -> cardLayout.show(mainPanel, "payment"));
        back.addActionListener(e -> cardLayout.show(mainPanel, "dashboard"));

        JPanel bottomPanel = new JPanel(new GridLayout(2, 1));
        JPanel buttonRow = new JPanel();
        buttonRow.add(totalLabel);
        buttonRow.add(checkout);
        buttonRow.add(back);

        bottomPanel.add(buttonRow);

        panel.add(title, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        return panel;
    }

    private void updateCartDisplay() {
        cartItemsPanel.removeAll();
        int total = 0;
        int orderNum = 1;

        for (CartItem item : cart) {
            JPanel itemPanel = new JPanel(new BorderLayout(10, 10));
            itemPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            itemPanel.setBackground(Color.WHITE);

            String imagePath = getProductImage(item.productId);
            ImageIcon icon = new ImageIcon(imagePath);
            JLabel imageLabel = new JLabel(icon);

            JLabel textLabel = new JLabel("<html>Order #" + orderNum + "<br>Product ID: " + item.productId + 
                "<br>Name: " + item.name + "<br>Qty: " + item.quantity + 
                "<br>Price: " + (item.price * item.quantity) + " SAR</html>");
            textLabel.setFont(new Font("Arial", Font.PLAIN, 14));

            JButton deleteButton = new JButton("X");
            deleteButton.addActionListener(e -> {
                cart.remove(item);
                updateCartDisplay();
                updateCartCount();
            });

            itemPanel.add(imageLabel, BorderLayout.WEST);
            itemPanel.add(textLabel, BorderLayout.CENTER);
            itemPanel.add(deleteButton, BorderLayout.EAST);

            cartItemsPanel.add(itemPanel);
            cartItemsPanel.add(Box.createRigidArea(new Dimension(0, 10)));

            total += item.price * item.quantity;
            orderNum++;
        }

        totalLabel.setText("Total: " + total + " SAR");
        cartItemsPanel.revalidate();
        cartItemsPanel.repaint();
    }

    private String getProductImage(int productId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT image_path FROM products WHERE product_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, productId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getString("image_path");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "default.png";
    }

   private JPanel createPaymentPanel() {
    JPanel panel = new JPanel();
    panel.setLayout(null);
    panel.setPreferredSize(new Dimension(500, 300));
    panel.setBackground(new Color(230, 240, 250));

    JLabel title = new JLabel("Payment method");
    title.setFont(new Font("Arial", Font.BOLD, 20));
    title.setBounds(170, 20, 200, 30);
    panel.add(title);

    JLabel instruction = new JLabel("Choose your payment method");
    instruction.setBounds(150, 60, 250, 20);
    panel.add(instruction);

    // Radio buttons
    JRadioButton creditBtn = new JRadioButton("Credit card");
    creditBtn.setBounds(150, 100, 120, 25);
    creditBtn.setBackground(new Color(230, 240, 250));

    JRadioButton cashBtn = new JRadioButton("Cash");
    cashBtn.setBounds(150, 130, 120, 25);
    cashBtn.setBackground(new Color(230, 240, 250));

    ButtonGroup group = new ButtonGroup();
    group.add(creditBtn);
    group.add(cashBtn);

    // Icons (dummy for now)
    JLabel creditIcon = new JLabel(new ImageIcon("credit.jpg")); // replace with actual image
    creditIcon.setBounds(300, 95, 50, 40);
    JLabel cashIcon = new JLabel(new ImageIcon("cash.jpg")); // replace with actual image
    cashIcon.setBounds(300, 140, 50, 30);

    panel.add(creditBtn);
    panel.add(cashBtn);
    panel.add(creditIcon);
    panel.add(cashIcon);

    // Buttons
    JButton cancel = new JButton("Cancel");
    cancel.setBounds(130, 200, 100, 30);

    JButton pay = new JButton("Pay");
    pay.setBounds(260, 200, 100, 30);

    panel.add(cancel);
    panel.add(pay);

    cancel.addActionListener(e -> cardLayout.show(mainPanel, "cart"));

    pay.addActionListener(e -> {
        if (creditBtn.isSelected()) {
            cardLayout.show(mainPanel, "creditForm");
        } else if (cashBtn.isSelected()) {
            processPayment();
        } else {
            JOptionPane.showMessageDialog(panel, "Please select a payment method.");
            createCreditCardFormPanel();
            
        }
    });

    return panel;
}

private JPanel createCreditCardFormPanel() {
    JPanel panel = new JPanel();
    panel.setLayout(null);
    panel.setPreferredSize(new Dimension(500, 350));
    panel.setBackground(new Color(230, 240, 250));

    JLabel title = new JLabel("Add payment method");
    title.setFont(new Font("Arial", Font.BOLD, 20));
    title.setBounds(140, 20, 250, 30);
    panel.add(title);

    JLabel cardLabel = new JLabel("Card number:");
    cardLabel.setBounds(80, 70, 150, 20);
    JTextField cardField = new JTextField();
    cardField.setBounds(200, 70, 200, 25);

    JLabel nameLabel = new JLabel("Number:");
    nameLabel.setBounds(80, 110, 150, 20);
    JTextField nameField = new JTextField();
    nameField.setBounds(200, 110, 200, 25);

    JLabel expiryLabel = new JLabel("Expiry date:");
    expiryLabel.setBounds(80, 150, 150, 20);
    JTextField monthField = new JTextField("MM");
    monthField.setBounds(200, 150, 40, 25);
    JTextField yearField = new JTextField("YYYY");
    yearField.setBounds(250, 150, 60, 25);

    JLabel cvvLabel = new JLabel("CVV:");
    cvvLabel.setBounds(80, 190, 150, 20);
    JTextField cvvField = new JTextField();
    cvvField.setBounds(200, 190, 80, 25);

    JCheckBox saveCard = new JCheckBox("save card");
    saveCard.setBounds(80, 230, 150, 25);
    saveCard.setBackground(new Color(230, 240, 250));

    JButton pay = new JButton("Pay");
    pay.setBounds(200, 270, 100, 30);
    
    JButton bc = new JButton("Back");
    bc.setBounds(300, 270, 100, 30);
    panel.add(bc);
    panel.add(cardLabel);
    panel.add(cardField);
    panel.add(nameLabel);
    panel.add(nameField);
    panel.add(expiryLabel);
    panel.add(monthField);
    panel.add(yearField);
    panel.add(cvvLabel);
    panel.add(cvvField);
    panel.add(saveCard);
    panel.add(pay);
     bc.addActionListener(e -> cardLayout.show(mainPanel, "dashboard"));
 pay.addActionListener(e -> {
        createDashboardPanel();
    });
    pay.addActionListener(e -> {
        System.out.println(cardField.getText());
        if(cardField.getText().equals("")){            JOptionPane.showMessageDialog(this, "Fill card destails");
}else{
        processPayment();}
    });

    return panel;
}


    private void processPayment() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your cart is empty", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
       

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false); // Start transaction
            
            try {
                // Create order
                String orderSql = "INSERT INTO orders (customer_id, total_amount) VALUES (?, ?)";
                int orderId;
                
                try (PreparedStatement orderStmt = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                    orderStmt.setInt(1, customerId);
                    orderStmt.setDouble(2, calculateTotal());
                    orderStmt.executeUpdate();
                    
                    ResultSet rs = orderStmt.getGeneratedKeys();
                    if (rs.next()) {
                        orderId = rs.getInt(1);
                    } else {
                        throw new SQLException("Failed to create order");
                    }
                }
                
                // Add order items
                String itemSql = "INSERT INTO order_items (order_id, product_id, size, color, quantity, price) " +
                                 "VALUES (?, ?, ?, ?, ?, ?)";
                
                try (PreparedStatement itemStmt = conn.prepareStatement(itemSql)) {
                    for (CartItem item : cart) {
                        itemStmt.setInt(1, orderId);
                        itemStmt.setInt(2, item.productId);
                        itemStmt.setString(3, "M"); // Default size - would come from UI in real app
                        itemStmt.setString(4, "Black"); // Default color
                        itemStmt.setInt(5, item.quantity);
                        itemStmt.setDouble(6, item.price);
                        itemStmt.addBatch();
                    }
                    itemStmt.executeBatch();
                }
                
                // Update inventory
                String inventorySql = "UPDATE inventory SET quantity = quantity - ? " +
                                     "WHERE product_id = ? AND size = ? AND color = ?";
                
                try (PreparedStatement inventoryStmt = conn.prepareStatement(inventorySql)) {
                    for (CartItem item : cart) {
                        inventoryStmt.setInt(1, item.quantity);
                        inventoryStmt.setInt(2, item.productId);
                        inventoryStmt.setString(3, "M"); // Default size
                        inventoryStmt.setString(4, "Black"); // Default color
                        inventoryStmt.addBatch();
                    }
                    inventoryStmt.executeBatch();
                }
                
                conn.commit(); // Commit transaction
                
                JOptionPane.showMessageDialog(this, "🎉 Thank you for your purchase!", 
                    "Payment Successful", JOptionPane.INFORMATION_MESSAGE);
                
                cart.clear();
                updateCartDisplay();
                updateCartCount();
                cardLayout.show(mainPanel, "dashboard");
                
            } catch (SQLException ex) {
                conn.rollback(); // Rollback on error
                throw ex;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error processing payment: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int calculateTotal() {
        int total = 0;
        for (CartItem item : cart) {
            total += item.price * item.quantity;
        }
        return total;
    }

    private void addToCart(int productId, String name, int price) {
        for (CartItem item : cart) {
            if (item.productId == productId) {
                item.quantity++;
                updateCartDisplay();
                updateCartCount();
                return;
            }
        }
        cart.add(new CartItem(productId, name, price, 1));
        updateCartDisplay();
        updateCartCount();
    }

    private void updateCartCount() {
        int count = 0;
        for (CartItem item : cart) {
            count += item.quantity;
        }
        cartCountLabel.setText(String.valueOf(count));
    } 
    class CartItem {
        int productId;
        String name;
        int price;
        int quantity;

        CartItem(int productId, String name, int price, int quantity) {
            this.productId = productId;
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }
    }}