/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author IIslamsoft
 */
class CustomerOrdersPanel extends JPanel {
    private JTable ordersTable;
    private DefaultTableModel tableModel;

    public CustomerOrdersPanel(int employeeId) {
        setLayout(new BorderLayout());
        
        // Table setup
        String[] columns = {"Order ID", "Customer", "Products", "Status", "Date", "Amount"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3; // Only status column is editable
            }
        };
        ordersTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(ordersTable);
        
        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton updateButton = new JButton("Update Status");
        buttonPanel.add(updateButton);
        
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        updateButton.addActionListener(e -> updateOrderStatus());

        // Load data
        loadOrderData();
    }

    private void loadOrderData() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT o.order_id, c.name AS customer_name, " +
                         "GROUP_CONCAT(p.name SEPARATOR ', ') AS products, " +
                         "o.status, o.order_date, o.total_amount " +
                         "FROM orders o " +
                         "JOIN customers c ON o.customer_id = c.customer_id " +
                         "JOIN order_items oi ON o.order_id = oi.order_id " +
                         "JOIN products p ON oi.product_id = p.product_id " +
                         "GROUP BY o.order_id";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();
                tableModel.setRowCount(0); // Clear existing data
                
                while (rs.next()) {
                    Object[] row = {
                        rs.getInt("order_id"),
                        rs.getString("customer_name"),
                        rs.getString("products"),
                        rs.getString("status"),
                        rs.getTimestamp("order_date"),
                        rs.getDouble("total_amount")
                    };
                    tableModel.addRow(row);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading order data: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void updateOrderStatus() {
    int selectedRow = ordersTable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an order to update.");
        return;
    }

    int orderId = (int) tableModel.getValueAt(selectedRow, 0);

    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "UPDATE orders SET status = ? WHERE order_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "Delivered");
            stmt.setInt(2, orderId);
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                tableModel.setValueAt("Delivered", selectedRow, 3); // Update table view
                JOptionPane.showMessageDialog(this, "Order status updated to 'Delivered'.");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update order status.");
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error updating order status: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}


}