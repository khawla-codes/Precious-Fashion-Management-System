/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author IIslamsoft
 */
class CustomerReviewsPanel extends JPanel {
    private JTable reviewsTable;
    private DefaultTableModel tableModel;

    public CustomerReviewsPanel() {
        setLayout(new BorderLayout());
        
        // Table setup
        String[] columns = {"Review ID", "Product", "Customer", "Review", "Date"};
        tableModel = new DefaultTableModel(columns, 0);
        reviewsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(reviewsTable);
        
        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton deleteButton = new JButton("Delete Review");
        buttonPanel.add(deleteButton);
        deleteButton.addActionListener(e -> deleteSelectedReview());

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load data
        loadReviewData();
    }

    private void loadReviewData() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT r.review_id, p.name AS product_name, c.name AS customer_name, " +
                         "r.review_text, r.review_date FROM reviews r " +
                         "JOIN products p ON r.product_id = p.product_id " +
                         "JOIN customers c ON r.customer_id = c.customer_id";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();
                tableModel.setRowCount(0); // Clear existing data
                
                while (rs.next()) {
                    Object[] row = {
                        rs.getInt("review_id"),
                        rs.getString("product_name"),
                        rs.getString("customer_name"),
                        rs.getString("review_text"),
                        rs.getTimestamp("review_date")
                    };
                    tableModel.addRow(row);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading review data: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void deleteSelectedReview() {
    int selectedRow = reviewsTable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a review to delete.");
        return;
    }

    int reviewId = (int) tableModel.getValueAt(selectedRow, 0);

    int confirm = JOptionPane.showConfirmDialog(this,
        "Are you sure you want to delete this review?",
        "Confirm Deletion",
        JOptionPane.YES_NO_OPTION);

    if (confirm == JOptionPane.YES_OPTION) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM reviews WHERE review_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, reviewId);
                int rowsDeleted = stmt.executeUpdate();

                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(this, "Review deleted successfully.");
                    loadReviewData(); // Refresh table
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete review.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting review: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

}
