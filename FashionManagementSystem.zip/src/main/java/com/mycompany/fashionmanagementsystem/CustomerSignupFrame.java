/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author IIslamsoft
 */
class CustomerSignupFrame extends JFrame {
    private JTextField usernameField, nameField, phoneField, addressField;
    private JPasswordField passwordField, confirmPasswordField;

    public CustomerSignupFrame() {
        setTitle("Customer Sign Up");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(234, 242, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Customer Registration", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        addFormField(panel, gbc, "Username:", usernameField = new JTextField(20), 1);
        addFormField(panel, gbc, "Password:", passwordField = new JPasswordField(20), 2);
        addFormField(panel, gbc, "Confirm Password:", confirmPasswordField = new JPasswordField(20), 3);
        addFormField(panel, gbc, "Full Name:", nameField = new JTextField(20), 4);
        addFormField(panel, gbc, "Phone:", phoneField = new JTextField(20), 5);
        addFormField(panel, gbc, "Address:", addressField = new JTextField(20), 6);

        gbc.gridy = 7;
        gbc.gridwidth = 2;
        JButton registerBtn = new JButton("Register");
        registerBtn.setBackground(new Color(50, 50, 50));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.addActionListener(e -> registerCustomer());
        panel.add(registerBtn, gbc);

        add(panel);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, String label, JComponent field, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel(label), gbc);
        
        gbc.gridx = 1;
        panel.add(field, gbc);
    }

   private void registerCustomer() {
    // Get all field values
    String username = usernameField.getText().trim();
    String password = new String(passwordField.getPassword()).trim();
    String confirmPassword = new String(confirmPasswordField.getPassword()).trim();
    String name = nameField.getText().trim();
    String phone = phoneField.getText().trim();
    String address = addressField.getText().trim();

    // Validate fields
    if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || 
        name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
        JOptionPane.showMessageDialog(this, "All fields are required", 
            "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(this, "Passwords do not match", 
            "Error", JOptionPane.ERROR_MESSAGE);
        passwordField.setText("");
        confirmPasswordField.setText("");
        return;
    }

    if (password.length() < 6) {
        JOptionPane.showMessageDialog(this, "Password must be at least 6 characters", 
            "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!phone.matches("\\d{10,15}")) {
        JOptionPane.showMessageDialog(this, "Phone number must be 10-15 digits", 
            "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Check if username already exists
    try (Connection conn = DatabaseConnection.getConnection()) {
        // Check username availability
        String checkSql = "SELECT username FROM customers WHERE username = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Username already exists", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insert new customer
        String insertSql = "INSERT INTO customers (username, password, name, phone, address) " +
                          "VALUES (?, SHA1(?), ?, ?, ?)";
        try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
            insertStmt.setString(1, username);
            insertStmt.setString(2, password);
            insertStmt.setString(3, name);
            insertStmt.setString(4, phone);
            insertStmt.setString(5, address);
            
            int rowsAffected = insertStmt.executeUpdate();
            
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Registration successful! Please login.", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Close the registration window
            } else {
                JOptionPane.showMessageDialog(this, "Registration failed", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}
}