/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 *
 * @author IIslamsoft
 */
class EmployeeMainFrame extends JFrame {
    public EmployeeMainFrame(int employeeId) {
        setTitle("Employee Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Customer Orders Tab
        tabbedPane.addTab("Customer Orders", new CustomerOrdersPanel(employeeId));
        
        // Inventory Management Tab
        tabbedPane.addTab("Inventory Management", new InventoryManagementPanel());
        
        add(tabbedPane);
    }
}
