/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author IIslamsoft
 */
class EmployeeManagementPanel extends JPanel {
    private JTable employeeTable;
    private DefaultTableModel tableModel;

    public EmployeeManagementPanel() {
        setLayout(new BorderLayout());

        // Table setup
        String[] columns = {"Employee ID", "Username", "Name", "Admin Role", "Manager ID"};
        tableModel = new DefaultTableModel(columns, 0);
        employeeTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(employeeTable);

        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Employee");
        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Load data
        loadEmployeeData();

        // Button functionality
        addButton.addActionListener(e -> addEmployee());
        editButton.addActionListener(e -> editSelectedEmployee());
        deleteButton.addActionListener(e -> deleteSelectedEmployee());
    }

    private void loadEmployeeData() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT employee_id, username, name, is_admin, manager_id FROM employees";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();
                tableModel.setRowCount(0); // Clear existing data

                while (rs.next()) {
                    Object[] row = {
                        rs.getInt("employee_id"),
                        rs.getString("username"),
                        rs.getString("name"),
                        rs.getBoolean("is_admin") ? "Yes" : "No",
                        rs.getInt("manager_id")
                    };
                    tableModel.addRow(row);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading employee data: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addEmployee() {
        String username = JOptionPane.showInputDialog(this, "Enter username:");
        String name = JOptionPane.showInputDialog(this, "Enter name:");
        String pass = JOptionPane.showInputDialog(this, "password:");
        int isAdmin = JOptionPane.showConfirmDialog(this, "Is this an admin?", "Admin Role", JOptionPane.YES_NO_OPTION);
        String managerIdStr = JOptionPane.showInputDialog(this, "Enter manager ID:");

        if (username == null || name == null || managerIdStr == null) return;

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO employees (username, name,password, is_admin, manager_id) VALUES (?,?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, name);
                stmt.setString(3, pass);

                stmt.setBoolean(4, isAdmin == JOptionPane.YES_OPTION);
                stmt.setInt(5, Integer.parseInt(managerIdStr));
                stmt.executeUpdate();
                loadEmployeeData();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error adding employee: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editSelectedEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee to edit.");
            return;
        }

        int employeeId = (int) tableModel.getValueAt(selectedRow, 0);
        String currentUsername = (String) tableModel.getValueAt(selectedRow, 1);
        String currentName = (String) tableModel.getValueAt(selectedRow, 2);
        boolean isAdmin = tableModel.getValueAt(selectedRow, 3).equals("Yes");
        int currentManagerId = (int) tableModel.getValueAt(selectedRow, 4);

        String username = JOptionPane.showInputDialog(this, "Edit username:", currentUsername);
        String name = JOptionPane.showInputDialog(this, "Edit name:", currentName);
        int adminChoice = JOptionPane.showConfirmDialog(this, "Is this an admin?", "Admin Role", JOptionPane.YES_NO_OPTION);
        String managerIdStr = JOptionPane.showInputDialog(this, "Edit manager ID:", String.valueOf(currentManagerId));

        if (username == null || name == null || managerIdStr == null) return;

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE employees SET username = ?, name = ?, is_admin = ?, manager_id = ? WHERE employee_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, name);
                stmt.setBoolean(3, adminChoice == JOptionPane.YES_OPTION);
                stmt.setInt(4, Integer.parseInt(managerIdStr));
                stmt.setInt(5, employeeId);
                stmt.executeUpdate();
                loadEmployeeData();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error editing employee: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee to delete.");
            return;
        }

        int employeeId = (int) tableModel.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this employee?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM employees WHERE employee_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, employeeId);
                stmt.executeUpdate();
                loadEmployeeData();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting employee: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
