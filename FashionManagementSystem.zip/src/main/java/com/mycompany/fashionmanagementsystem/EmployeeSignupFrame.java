/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author IIslamsoft
 */
class EmployeeSignupFrame extends JFrame {
    private JTextField usernameField, nameField, employeeIdField;
    private JPasswordField passwordField, confirmPasswordField;
    private JComboBox<String> roleCombo;
    private JRadioButton maleRadio, femaleRadio;
    private ButtonGroup genderGroup;
    private JButton registerButton, cancelButton;

    public EmployeeSignupFrame() {
        setTitle("Employee Registration");
        setSize(500, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(234, 242, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Employee Registration", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        addFormField(panel, gbc, "Username:", usernameField = new JTextField(20), 1);
        addFormField(panel, gbc, "Password:", passwordField = new JPasswordField(20), 2);
        addFormField(panel, gbc, "Confirm Password:", confirmPasswordField = new JPasswordField(20), 3);
        addFormField(panel, gbc, "Full Name:", nameField = new JTextField(20), 4);
        addFormField(panel, gbc, "Employee ID:", employeeIdField = new JTextField(20), 5);

        // Role selection
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(new JLabel("Role:"), gbc);
        
        gbc.gridx = 1;
        roleCombo = new JComboBox<>(new String[]{"Staff", "Manager"});
        panel.add(roleCombo, gbc);

        // Gender selection
        gbc.gridx = 0;
        gbc.gridy = 7;
        panel.add(new JLabel("Gender:"), gbc);
        
        gbc.gridx = 1;
        JPanel genderPanel = new JPanel();
        genderGroup = new ButtonGroup();
        maleRadio = new JRadioButton("Male");
        femaleRadio = new JRadioButton("Female");
        maleRadio.setSelected(true);
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        panel.add(genderPanel, gbc);

        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        registerButton = new JButton("Register");
        cancelButton = new JButton("Cancel");
        
        registerButton.setBackground(new Color(50, 50, 50));
        registerButton.setForeground(Color.WHITE);
        registerButton.addActionListener(e -> registerEmployee());
        
        cancelButton.setBackground(new Color(50, 50, 50));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.addActionListener(e -> dispose());
        
        buttonPanel.add(registerButton);
        buttonPanel.add(cancelButton);
        panel.add(buttonPanel, gbc);

        add(panel);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, String label, JComponent field, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel(label), gbc);
        
        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private void registerEmployee() {
        // Get all field values
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String confirmPassword = new String(confirmPasswordField.getPassword()).trim();
        String name = nameField.getText().trim();
        String employeeId = employeeIdField.getText().trim();
        String role = (String) roleCombo.getSelectedItem();
        String gender = maleRadio.isSelected() ? "Male" : "Female";

        // Validate fields
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || 
            name.isEmpty() || employeeId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match", 
                "Error", JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
            confirmPasswordField.setText("");
            return;
        }

        if (password.length() < 6) {
            JOptionPane.showMessageDialog(this, "Password must be at least 6 characters", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!employeeId.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Employee ID must be numeric", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if username already exists
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Check username availability
            String checkSql = "SELECT username FROM employees WHERE username = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, username);
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "Username already exists", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            // Check employee ID availability
            checkSql = "SELECT employee_id FROM employees WHERE employee_id = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setInt(1, Integer.parseInt(employeeId));
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "Employee ID already exists", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            // Insert new employee
            String insertSql = "INSERT INTO employees (employee_id, username, password, name, " +
                              "is_admin) VALUES (?, ?, SHA1(?), ?, ?)";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setInt(1, Integer.parseInt(employeeId));
                insertStmt.setString(2, username);
                insertStmt.setString(3, password);
                insertStmt.setString(4, name);
                insertStmt.setBoolean(5, false);
             
                
                int rowsAffected = insertStmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Registration successful! Employee can now login.", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                    dispose(); // Close the registration window
                } else {
                    JOptionPane.showMessageDialog(this, "Registration failed", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Employee ID format", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
