/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author IIslamsoft
 */
class InventoryManagementPanel extends JPanel {
    private JTable inventoryTable;
    private DefaultTableModel tableModel;
    private JButton increaseButton, decreaseButton, saveButton;

    public InventoryManagementPanel() {
        setLayout(new BorderLayout());
        
        // Table setup
        String[] columns = {"Product ID", "Product Name", "Size", "Color", "Quantity"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Only allow editing the Quantity column
                return column == 4;
            }
        };
        inventoryTable = new JTable(tableModel);
        inventoryTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(inventoryTable);
        
        // Buttons
        JPanel buttonPanel = new JPanel();
        increaseButton = new JButton("+");
        decreaseButton = new JButton("-");
        saveButton = new JButton("Save Changes");
        
        // Style buttons
        styleButton(increaseButton);
        styleButton(decreaseButton);
        styleButton(saveButton);
        
        // Add action listeners
        increaseButton.addActionListener(e -> adjustQuantity(1));
        decreaseButton.addActionListener(e -> adjustQuantity(-1));
        saveButton.addActionListener(e -> saveChanges());
        
        buttonPanel.add(increaseButton);
        buttonPanel.add(decreaseButton);
        buttonPanel.add(saveButton);
        
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load data
        loadInventoryData();
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(50, 50, 50));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createRaisedBevelBorder());
    }

    private void adjustQuantity(int change) {
        int selectedRow = inventoryTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product first!", 
                "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int currentQty = (int) tableModel.getValueAt(selectedRow, 4);
        int newQty = currentQty + change;
        
        if (newQty < 0) {
            JOptionPane.showMessageDialog(this, "Quantity cannot be negative!", 
                "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        tableModel.setValueAt(newQty, selectedRow, 4);
    }

    private void saveChanges() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false); // Start transaction
            
            try {
                String updateSql = "UPDATE inventory SET quantity = ? WHERE product_id = ? AND size = ? AND color = ?";
                try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                    for (int row = 0; row < tableModel.getRowCount(); row++) {
                        int productId = (int) tableModel.getValueAt(row, 0);
                        String size = (String) tableModel.getValueAt(row, 2);
                        String color = (String) tableModel.getValueAt(row, 3);
                        int quantity = (int) tableModel.getValueAt(row, 4);
                        
                        stmt.setInt(1, quantity);
                        stmt.setInt(2, productId);
                        stmt.setString(3, size);
                        stmt.setString(4, color);
                        stmt.addBatch();
                    }
                    
                    int[] results = stmt.executeBatch();
                    int updatedRows = 0;
                    for (int result : results) {
                        if (result >= 0) { // SUCCESS_NO_INFO (-2) or update count
                            updatedRows++;
                        }
                    }
                    
                    conn.commit(); // Commit transaction
                    
                    JOptionPane.showMessageDialog(this, 
                        "Successfully updated " + updatedRows + " inventory items!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException ex) {
                conn.rollback(); // Rollback on error
                throw ex;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error saving inventory changes: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadInventoryData() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT i.inventory_id, p.product_id, p.name, i.size, i.color, i.quantity " +
                         "FROM inventory i JOIN products p ON i.product_id = p.product_id";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();
                tableModel.setRowCount(0); // Clear existing data
                
                while (rs.next()) {
                    Object[] row = {
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getString("size"),
                        rs.getString("color"),
                        rs.getInt("quantity")
                    };
                    tableModel.addRow(row);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading inventory data: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
