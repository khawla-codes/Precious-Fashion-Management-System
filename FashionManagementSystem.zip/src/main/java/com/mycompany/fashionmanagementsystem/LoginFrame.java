/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author IIslamsoft
 */
class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signupButton;

   public LoginFrame() {
    setTitle("Fashion Management System - Login");
    setSize(1000, 600); // Wider size to fit form + logo nicely
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);

    // Main container
    JPanel mainPanel = new JPanel(new BorderLayout());
    mainPanel.setBackground(new Color(234, 242, 255));

    // Left: Login Form Panel
    JPanel formPanel = new JPanel(new GridBagLayout());
    formPanel.setBackground(new Color(234, 242, 255));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;

    JLabel titleLabel = new JLabel("Login to Fashion System", SwingConstants.CENTER);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    formPanel.add(titleLabel, gbc);

    gbc.gridwidth = 1;
    gbc.gridy = 1;
    formPanel.add(new JLabel("Username:"), gbc);

    gbc.gridx = 1;
    usernameField = new JTextField(15);
    formPanel.add(usernameField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 2;
    formPanel.add(new JLabel("Password:"), gbc);

    gbc.gridx = 1;
    passwordField = new JPasswordField(15);
    formPanel.add(passwordField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 3;
    gbc.gridwidth = 2;
    loginButton = new JButton("Login");
    loginButton.setBackground(new Color(50, 50, 50));
    loginButton.setForeground(Color.WHITE);
    loginButton.addActionListener(e -> authenticateUser());
    formPanel.add(loginButton, gbc);

    gbc.gridy = 4;
    signupButton = new JButton("Don't have an account? Sign Up");
    signupButton.setBorderPainted(false);
    signupButton.setContentAreaFilled(false);
    signupButton.setForeground(new Color(50, 50, 50));
    signupButton.addActionListener(e -> new SignupChoiceFrame().setVisible(true));
    formPanel.add(signupButton, gbc);

    // Right: Logo Panel
    JLabel logoLabel = new JLabel(new ImageIcon("logo.jpg"));
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    JPanel logoPanel = new JPanel(new BorderLayout());
    logoPanel.setBackground(new Color(234, 242, 255));
    logoPanel.add(logoLabel, BorderLayout.CENTER);

    // Add form and logo to main panel
    mainPanel.add(formPanel, BorderLayout.CENTER); // Form on left
    mainPanel.add(logoPanel, BorderLayout.WEST);    // Logo on right

    add(mainPanel);
}


    private void authenticateUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Check if admin
            String adminSql = "SELECT * FROM employees WHERE username = ? AND password = SHA1(?)";
            try (PreparedStatement stmt = conn.prepareStatement(adminSql)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    boolean isAdmin = rs.getBoolean("is_admin");
                    if (isAdmin) {
                        new AdminMainFrame().setVisible(true);
                    } else {
                        new EmployeeMainFrame(rs.getInt("employee_id")).setVisible(true);
                    }
                    dispose();
                    return;
                }
            }

            // Check if customer
            String customerSql = "SELECT * FROM customers WHERE username = ? AND password = SHA1(?)";
            try (PreparedStatement stmt = conn.prepareStatement(customerSql)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    new CustomerMainFrame(rs.getInt("customer_id")).setVisible(true);
                    dispose();
                    return;
                }
            }

            JOptionPane.showMessageDialog(this, "Invalid username or password", 
                "Error", JOptionPane.ERROR_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}