/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fashionmanagementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author IIslamsoft
 */
class SignupChoiceFrame extends JFrame {
    public SignupChoiceFrame() {
        setTitle("Choose Account Type");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(234, 242, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Create New Account", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        JButton employeeBtn = new JButton("Employee");
        employeeBtn.setBackground(new Color(50, 50, 50));
        employeeBtn.setForeground(Color.WHITE);
        employeeBtn.addActionListener(e -> {
            new EmployeeSignupFrame().setVisible(true);
            dispose();
        });
        panel.add(employeeBtn, gbc);

        gbc.gridx = 1;
        JButton customerBtn = new JButton("Customer");
        customerBtn.setBackground(new Color(50, 50, 50));
        customerBtn.setForeground(Color.WHITE);
        customerBtn.addActionListener(e -> {
            new CustomerSignupFrame().setVisible(true);
            dispose();
        });
        panel.add(customerBtn, gbc);

        add(panel);
    }
}
